import java.util.Scanner; 
import java.util.ArrayList;
import java.util.Arrays;
import java.io.*;
import java.lang.*;
import java.util.*;
/**
 * Write a description of class MyScanner here.
 *
 * @author Nishna Aerabati 
 * @version Nishna Aerabati 
 */
public class MyScanner
{
    
    private Scanner scan1;
    

    /**
     * Constructor for objects of class MyScanner
     */
    public MyScanner()
    {
        scan1 = new Scanner (System.in); 
       
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void Method1()
    {
    int sum = 0; 
    Scanner myInput = new Scanner(System.in );
    System.out.println("Please enter five integers with a space in between"); 
    for( int i = 0; i < 5; i++){
        sum = sum + myInput.nextInt(); 
        
    }
    
    System.out.println("the sum of the numbers is:" + sum); 
    System.out.println("the average of the numbers is:" + sum/5) ; 

    }
    
    
    public void Method2(){
        
        System.out.println( "Please input a new string"); 
        String userLine = scan1.nextLine();
        
        char c = userLine.charAt(0);
        int e = userLine.length(); 
        e = e -1; 
        char u = userLine.charAt(e); 
        
        System.out.println( c + " " + u); 
        
        
    }
    
    
    
    public void Method3()
    {
        System.out.println("Please input a line of text"); 
        String input = scan1.nextLine(); 
        String[] words = input.split(" "); 
        String[] newWords = new String[words.length]; 
       
        
        if(words[0].equals("define")){
            System.out.print("error"); 
        }
        
        for(int f = 0; f < words.length; f++){
           
            String currentWord = words[f];
            String newWord = currentWord.substring(0, 1).toUpperCase();
            newWord = newWord + currentWord.substring(1); 
            newWords[f] = newWord;
            
        }
        
        for( int r = 0; r < newWords.length; r++) 
        {
        System.out.print(newWords[r] + " "); 
        }
    }
    
    
    
    
    public void Method4()
    {
        System.out.println("Please input a new string"); 
        String string1 = scan1.nextLine(); 
        System.out.print("Please input another string");
        String string2 = scan1.nextLine(); 
       
        int compareValue = string1.compareTo(string2);
        
        if( compareValue > 1){
            System.out.println("The result is " +  compareValue + " and " + string1 +
            " is greater than " + string2); 
            
        }else if( compareValue == 0){
            System.out.println("The result is " +  compareValue + "and" + string1 +
            " is equal to " + string2); 
            
        }else if(compareValue < 0){
            
            System.out.println("The result is " +  compareValue + "and" + string1 +
            " is less than " + string2); 
           
        }

    }
}
