import java.util.Scanner;
import java.util.Scanner;
import java.io.File; 
import java.io.FileNotFoundException; 
/**
 * Write a description of class trackingDNA here.
 *
 * @author Nishna Aerabati
 * @version 9/23
 */
public class trackingDNA
{
    

    /**
     * Constructor for objects of class trackingDNA
     */
    public trackingDNA()
    {
        
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  The DNA sequence as a string, The nucleotide that needs 
     * to be matched, n = the number of times the nucleotide needs to be found
     * @return whether that sequence of nucleotides is found within the DNA
     * string 
     */
    public boolean isInData(String data, String nucleotide, int n)
    {
    String sequence = " "; 
    for( int i = 0; i < n; i++)
    {
      sequence = sequence + nucleotide;
    }
    int found = data.indexOf(sequence); 
    if( found == -1){
          return false;
    }
    int original = found; 
    sequence = sequence + nucleotide; 
    found = data.indexOf(sequence); 
    if( original == found){
    return false; 
    }else{
        return true; 
    } 
    }
    
    public boolean inData(String data, String nucleotide, int n)
    {
    boolean found = true; 
    String sequence = " "; 
    for( int i = 0; i < n; i++)
    {
      sequence = sequence + nucleotide;
    }
    
    if( data.contains(sequence) == true){
    sequence = sequence + nucleotide;
    if( data.contains(sequence) == true){
    found = false; 
    }}else{
        found = true; 
    } 
    return found; 
    
    }
    
    /**
     * @param the dna sequence you are testing 
     * This method prints out whether the inputted sequence is Charlies's 
     */ 
    
    public void isCharlie(String dataC){
    boolean firstNucleotide = inData(dataC, "AGAT", 6);
    boolean secondNucleotide = inData(dataC, "AATG", 1);
    boolean thirdNucleotide = inData(dataC, "TATC", 5);
    
    if( firstNucleotide == true && secondNucleotide == true && 
    thirdNucleotide == true){
        System.out.println(" This is Charlie's DNA match"); 
        
    }else{
        System.out.println("This is not Charlie's DNA, you can try another DNA sequence"); 
    }

    }
    /**
     * @param the dna sequence you are testing 
     * This method prints out whether the inputted sequence is Alice's 
     */ 
    public void isAlice(String dataA){
    boolean firstNucleotide = inData(dataA, "AGAT", 5);
    boolean secondNucleotide = inData(dataA, "AATG", 2);
    boolean thirdNucleotide = inData(dataA, "TATC", 8);
    
    if( firstNucleotide == true && secondNucleotide == true && 
    thirdNucleotide == true){
        System.out.println(" This is Alice's DNA match"); 
        
    }else{
        System.out.println("This is not Alice's DNA, you can try another DNA sequence"); 
    }
    
    }
    /**
     * @param the dna sequence you are testing 
     * This method prints out whether the inputted sequence is Bob's 
     */ 
    
    public void isBob(String dataB){
    boolean firstNucleotide = inData(dataB, "AGAT", 3);
    boolean secondNucleotide = inData(dataB, "AATG", 7);
    boolean thirdNucleotide = inData(dataB, "TATC", 4);
    
    if( firstNucleotide == true && secondNucleotide == true && 
    thirdNucleotide == true){
        System.out.println(" This is Bob's DNA match"); 
        
    }else{
        System.out.println("This is not Bob's DNA, you can try another DNA sequence"); 
    }

    

    }
}

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    