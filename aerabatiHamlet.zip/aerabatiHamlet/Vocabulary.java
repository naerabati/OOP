import java.io.PrintWriter;
import java.util.HashMap;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.*;
import java.io.*;

/**
 * Write a description of class Vocabulary here.
 *
 * @author Nishna Aerabati 
 * @version 11/15/2021
 */
public class Vocabulary
{
    private HashMap<String, Integer> map; 
    private PrintWriter pWriter; 

    /**
     * Constructor for objects of class Vocabulary
     */
    public Vocabulary()
    {
        map = new HashMap <String, Integer>();
    }

    /**
     *
     */
    public void read()throws FileNotFoundException
    {
        ArrayList<String[]> allWords = new ArrayList<>(); 
        ArrayList<String> lineWords = new ArrayList<>();
        File file = new File("hamlet (1).txt"); 
        Scanner scan = new Scanner(file);
        int i = 0; 
        while(scan.hasNextLine()){

            String word = scan.nextLine(); 
            allWords.add(i, word.split("\\s")); 
            i++; 
        }

        for(String[] word : allWords){
            for(String w: word){
                w = w.toLowerCase();
                w = w.replaceAll("[^a-z']", ""); 
                w = w.trim(); 

                lineWords.add(w); 

            }

        }        

        for(int v = 0; v < lineWords.size(); v++){
            String wor = lineWords.get(v); 
            int c = 1;
            for(int s = 0; s < lineWords.size(); s++){
                if(!(wor.equals(""))){
                  if(lineWords.get(s).equals(wor)){
                    map.put(wor, c++);  
                }   
                }
            }

        }

    }

    public int findDifferent(){
    int diffCount = map.size(); 
    return diffCount; 
    }
    
    public String findMax(){
        String m = ""; 
        int max = 0; 
        for(String key : map.keySet()){
            
            int x = map.get(key); 

            if( x > max){
                max = x; 
                m = key; 
                
            }

        }
        return m; 
    }
    
    public HashMap commonWords(){
        HashMap<String, Integer> common = new HashMap <String, Integer>(); 
        int theCount = map.get("the"); 
        int anCount = map.get("an"); 
        int aCount = map.get("a"); 
        common.put("the", theCount); 
        common.put("an", anCount); 
        common.put("a", aCount); 
        return common; 
    }
    
    public void print(){
       
        for(String key : map.keySet()){
            String k = key; 
            int value = map.get(k); 

            System.out.printf("%s appears %d times.\n", key, value); 

        }

        System.out.println("There are " + findDifferent() + " different words.");

        System.out.println("Word " + "'" + findMax()  +"'" + " is the most used: " +  "wordCount.get(findMax())" + " times"); 
       

        HashMap<String, Integer> c = commonWords(); 

        System.out.println("'an' was used: " + c.get("an") + " times");
        System.out.println("'a' was used: " + c.get("a") + " times");
        System.out.println("'The' was used: " + c.get("the")+  " times");

    }

    public void writeToFile() throws IOException{
        FileWriter fWriter = new FileWriter(new File("output.txt"));
        PrintWriter pWriter = new PrintWriter(fWriter);
        pWriter.print(map);  
        pWriter.print("There are " + map.size() + " different words.");
        pWriter.print("The most common word is " + map.get(findMax()));
        pWriter.print("'an' was used: " + map.get("an") + " times");
        pWriter.print("'a' was used: " + map.get("an") + " times");
        pWriter.print("'The' was used: " + map.get("an") + " times");
        System.out.println("Your summary is written to a file"); 
        pWriter.close(); 
    }

}
