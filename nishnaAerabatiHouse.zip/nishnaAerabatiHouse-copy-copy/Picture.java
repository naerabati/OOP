import java.util.*;
import java.awt.color.*; 
import java.awt.*;

/**
 * This class represents a simple picture. You can draw the picture using
 * the draw method. But wait, there's more: being an electronic picture, it
 * can be changed. You can set it to black-and-white display and back to
 * colors (only after it's been drawn, of course).
 *
 * This class was written as an early example for teaching Java with BlueJ.
 * 
 * @author  Nishna Aerabati
 * @version : 8/27/2021
 * 
 * 
 * House assignment - change the house to appear in the night and back to the sunrise
 */
public class Picture
{
    private Square wall;
    private Square backgroundColor;
    private Square window;
    private Triangle roof;
    private Circle sun;
    private boolean drawn;
    private Circle moon;
    private Square background;
    private Circle star1;
    private Circle star2;
    private Circle star3;
    private Circle star4;
    private Circle star5;
    private Circle star6;
    private Circle star7;
    private Circle star8;
    private Circle star9;
    private Circle star10;
    private Circle star11;
    private Rectangle grass;
    private Circle sun2;

    

    /**
     * Constructor for objects of class Picture
     */
    public Picture()
    {
        wall = new Square();
        window = new Square();
        roof = new Triangle();  
        sun = new Circle();
        moon = new Circle();
        background = new Square();
        star1 = new Circle();
        star2 = new Circle();
        star3 = new Circle();
        star4 = new Circle();
        star5 = new Circle();
        star6 = new Circle();
        star7= new Circle();
        star8 = new Circle();
        star9 = new Circle();
        star10 = new Circle();
        star11 = new Circle();
        grass = new Rectangle();
        sun2 = new Circle();
        drawn = false;
        
    }
    

    /**
     * Draw this picture.
     */
    public void draw()
    {
        if(!drawn) {
            
            background.changeColor("black");
            background.changeSize(10000);
            background.moveHorizontal(-500);
            background.moveVertical(-500);
            background.makeVisible();
            
            wall.changeColor("blue");
            wall.moveHorizontal(-140);
            wall.moveVertical(20);
            wall.changeSize(120);
            wall.makeVisible();
            
            window.changeColor("white");
            window.moveHorizontal(-120);
            window.moveVertical(40);
            window.changeSize(40);
            window.makeVisible();
    
            roof.changeSize(60, 180);
            roof.moveHorizontal(20);
            roof.moveVertical(-60);
            roof.makeVisible();
    
            int x;
            x = 100;
            moon.changeColor("white");
            int moonHeight;
            moon.moveHorizontal(x);
            moonHeight = x;
            moon.moveVertical(-40);
            moon.changeSize(80);
            moon.makeVisible();
            drawn = true;
            
            sun.changeColor("black");
    
            sun.moveHorizontal(100);
            sun.moveVertical(-40);
            sun.changeSize(60);
            sun.makeVisible();
            drawn = true;
            
            sun2.changeColor("black");
            sun2.moveHorizontal(-170);
            sun2.moveVertical(100);
            sun2.changeSize(60);
            sun2.makeVisible();
            drawn = true;
            
            star1.changeColor("white");
            star1.moveHorizontal(50);
            star1.moveVertical(-30);
            star1.changeSize(5);
            star1.makeVisible();
            drawn = true;
            
            star2.changeColor("white");
            star2.moveHorizontal(-40);
            star2.moveVertical(-40);
            star2.changeSize(5);
            star2.makeVisible();
            drawn = true;
            
            star3.changeColor("white");
            star3.moveHorizontal(170);
            star3.moveVertical(80);
            star3.changeSize(5);
            star3.makeVisible();
            drawn = true;
            
            /**done
             * 
             */
            star4.changeColor("white");
            star4.moveHorizontal(-170);
            star4.moveVertical(70);
            star4.changeSize(5);
            star4.makeVisible();
            drawn = true;
            
            star5.changeColor("white");
            star5.moveHorizontal(-100);
            star5.moveVertical(-20);
            star5.changeSize(5);
            star5.makeVisible();
            drawn = true;
            
            star6.changeColor("white");
            star6.moveHorizontal(120);
            star6.moveVertical(120);
            star6.changeSize(5);
            star6.makeVisible();
            drawn = true;
            
            
            star7.changeColor("white");
            star7.moveHorizontal(-110);
            star7.moveVertical(100);
            star7.changeSize(5);
            star7.makeVisible();
            drawn = true;
            
            star8.changeColor("white");
            star8.moveHorizontal(170);
            star8.moveVertical(-70);
            star8.changeSize(5);
            star8.makeVisible();
            drawn = true;
            
            star9.changeColor("white");
            star9.moveHorizontal(-200);
            star9.moveVertical(-70);
            star9.changeSize(5);
            star9.makeVisible();
            drawn = true;
            
            star10.changeColor("white");
            star10.moveHorizontal(-190);
            star10.moveVertical(10);
            star10.changeSize(5);
            star10.makeVisible();
            drawn = true;
            
            star11.changeColor("white");
            star11.moveHorizontal(240);
            star11.moveVertical(-10);
            star11.changeSize(5);
            star11.makeVisible();
            drawn = true;
         

            

            
            
        }
    }

    /**
     * Change this picture to black/white display
     */
    public void setBlackAndWhite()
    {
        wall.changeColor("black");
        window.changeColor("white");
        roof.changeColor("black");
        sun.changeColor("black");
    }

    /**
     * Change this picture to use color display
     */
    public void setColor()
    {
        wall.changeColor("blue");
        window.changeColor("black");
        roof.changeColor("green");
        sun.changeColor("black");
        background.changeColor("black");
    }
   
    
     

    /**
     * Function sunrise changes the backgorund to white, makes the sun yellow, 
     * changes the colors of the walls, and makes the grass visible 
     */
    public void sunrise()
    {
        
        background.slowMoveVertical(500);
        wall.changeColor("red");
        window.changeColor("black");
        roof.changeColor("green");
        moon.changeColor("white");
        
        sun.slowMoveVertical(300);
        moon.slowMoveVertical(300);
        sun2.changeColor("yellow");
        sun2.slowMoveVertical(-200);
        background.slowMoveVertical(500);
       
        
        
    }
    
    
        
}
