import java.util.Scanner; 
import java.util.Random;
import java.util.Arrays; 
/**
 * Write a description of class randomExercise here.
 *
 * @author Nishna Aerabati 
 * @version 10/15/2021
 */
public class randomExercise
{
    
    private Scanner scan;
    private int length; 
    private int[] randomNumberArray; 
    private Random rng; 
    /**
     * Constructor for objects of class randomExercise
     */
    public randomExercise()
    {
        scan = new Scanner(System.in);  
        rng = new Random(); 
        getArrayNumber();
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void getArrayNumber()
    {
       System.out.println("Please input an integer for the length of the array");
       length = scan.nextInt();  
       randomNumberArray = new int[length];
       createRandomNumberArray(); 
       
    }
    
    public void createRandomNumberArray(){
        int rNumber = 0; 
        for(int i = 0; i < length; i++){
       rNumber = 0; 
       rNumber = rng.nextInt(100);  
       
       randomNumberArray[i] = rNumber; 
       
    }
    formatArray();
    }
    
    public void formatArray(){
    
       
        for( int y = 0; y < length; y++){
        if( y%5 == 0){
            System.out.printf( "%5s\n ", randomNumberArray[y]);
            
            
        }   else{
            System.out.printf( "%5s, ", randomNumberArray[y] ); 
        }
        
    }
    calculateAverage(); 
    }
    
    public void calculateAverage(){
        int sum = 0; 
        
        for( int i = 0; i < length; i++){
          sum = randomNumberArray[i] + sum;    
        }
        
        
        int average = sum/length; 
        System.out.println(" "); 
        System.out.println("The average is " + average); 
    }
}
