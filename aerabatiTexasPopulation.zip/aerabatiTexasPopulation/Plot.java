
/**
 * Write a description of class Plot here.
 *
 * @author Nishna Aerabati
 * @version (a version number or a date)
 */
public class Plot
{
    private SimpleCanvas canvas;
    private int width;
    private int height;
    private int plotW;
    private int plotH;
    private int plotX0;
    private int plotY0;

    /**
     * Constructor for objects of class Plot
     */
    public Plot(int w, int h)
    {
        width = w;
        height = h;
        plotW = (int)(width*0.8);
        plotH = (int)(height*0.1);
        plotX0 = (int)(width*.1);
        plotY0 = (int)(height*.9);

        canvas = new SimpleCanvas("Texas Population 1st Digit Spread", width, height);
        drawGridLines();
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void drawGridLines()
    {
        canvas.drawLine(plotX0,plotY0,plotW,plotY0);
        canvas.drawLine(plotX0+10,plotY0,plotX0-15, plotY0); 
        canvas.drawLine(plotX0,plotH,plotX0,plotY0);
        canvas.drawLine(plotX0,plotY0,plotX0,plotY0+15);
        canvas.drawLine(plotX0+15,plotH,plotX0-15,plotH);
        for (int i =2;i<11;i++){
            canvas.drawLine(plotW*i/11,plotY0+15,plotW*i/11,plotY0-15);
            canvas.drawString(String.valueOf(i-1),plotW*i/11,plotY0+height/35);
        }
        
        for (int i =6;i>1;i--){
            canvas.drawLine(plotX0+15,plotY0*i/6,plotX0-15,plotY0*i/6);
        }
        for (int i = 6;i>0;i--){
            int d = (6-i)*10;
            d = d;

            String s = String.valueOf(d);

            canvas.drawString(s,plotX0-15,plotY0*i/6);
        }
    }
    
    public void drawGraph(int digit, int percentage ){
        digit = digit+1;
        int g = (plotY0-plotH) * percentage; 
        int[] x = new int[]{plotW*percentage/11+10,plotW*percentage/11-10,plotW*percentage/11-10, plotW*percentage/11+10};
        int[] y = new int[]{plotY0,plotY0,plotY0*(110-percentage)/110,plotY0*(110-percentage)/110};
        canvas.drawPolygon(x,y,4);
    }
}

